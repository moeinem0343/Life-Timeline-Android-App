# Life Timeline v0.1 — نسخه سازگار با ابزارهای ۲۰۲۶

این پروژه یک MVP آفلاین اندروید برای ثبت اتفاق‌های مهم زندگی با تاریخ شمسی است.

## مشخصات Build

- Android Gradle Plugin: 9.4.0
- Gradle: 9.6
- JDK: 17
- compileSdk: 36
- targetSdk: 36
- minSdk: 26
- زبان: Java
- Build اصلی از طریق GitHub Actions انجام می‌شود و پروژه برای اجرای مستقیم Gradle نیز تنظیم شده است.

## ساخت APK بدون PC — GitHub Actions

1. یک Repository جدید در GitHub بساز.
2. محتویات این پوشه را مستقیماً در ریشه Repository قرار بده؛ پوشه `app` باید در ریشه باشد.
3. فایل `.github/workflows/build-apk.yml` باید روی branch پیش‌فرض Repository (معمولاً `main`) قرار گرفته باشد.
4. در GitHub وارد تب `Actions` شو.
5. از ستون سمت چپ `Build Life Timeline APK` را انتخاب کن.
6. دکمه `Run workflow` را بزن.
7. در اجرای دستی می‌توانی `debug` یا `release` را انتخاب کنی.
8. پس از سبز شدن اجرای Workflow، وارد صفحه همان Run شو.
9. پایین صفحه بخش `Artifacts` را باز کن و `LifeTimeline-APK` را دانلود کن.
10. فایل ZIP دانلودشده را باز کن و APK را روی گوشی نصب کن.

### نکته درباره Release

Release این نسخه فعلاً unsigned است و برای تست مناسب است. برای انتشار عمومی در Google Play باید بعداً signing و keystore اضافه شود.

## اگر Run workflow را نمی‌بینی

- مطمئن شو فایل workflow دقیقاً در `.github/workflows/` است.
- مطمئن شو تغییر فایل workflow روی branch پیش‌فرض Repository ثبت شده است.
- مطمئن شو فایل شامل `workflow_dispatch:` است.
- سپس صفحه Actions را Refresh کن.

## قابلیت‌های فعلی MVP

- رابط فارسی و RTL
- Timeline اتفاق‌ها
- تاریخ شمسی
- ثبت عنوان، دسته‌بندی و توضیح
- اتصال اتفاق به Contact گوشی
- ذخیره محلی آفلاین
- نمایش جزئیات و حذف اتفاق

## نسخه‌های بعدی

Reminder شمسی، عکس، جست‌وجو، Backup/Restore، Dark Mode، تکرار سالانه و امکانات Timeline پیشرفته‌تر.
