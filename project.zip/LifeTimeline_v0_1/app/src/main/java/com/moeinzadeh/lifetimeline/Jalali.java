package com.moeinzadeh.lifetimeline;

import java.time.LocalDate;

public final class Jalali {
    private Jalali() {}
    public static int[] toJalali(LocalDate d) {
        int gy=d.getYear(), gm=d.getMonthValue(), gd=d.getDayOfMonth();
        int[] gdm={0,31,28,31,30,31,30,31,31,30,31,30,31};
        int gy2=gy-1600, gm2=gm-1, gd2=gd-1;
        int gDayNo=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400;
        for(int i=0;i<gm2;i++) gDayNo+=gdm[i+1];
        if(gm>2 && ((gy%4==0&&gy%100!=0)||gy%400==0)) gDayNo++;
        gDayNo+=gd2; int jDayNo=gDayNo-79;
        int jNp=jDayNo/12053; jDayNo%=12053;
        int jy=979+33*jNp+4*(jDayNo/1461); jDayNo%=1461;
        if(jDayNo>=366){jy+=(jDayNo-1)/365; jDayNo=(jDayNo-1)%365;}
        int jm=jDayNo<186?1+jDayNo/31:7+(jDayNo-186)/30;
        int jd=1+(jDayNo<186?jDayNo%31:(jDayNo-186)%30);
        return new int[]{jy,jm,jd};
    }
    public static LocalDate toGregorian(int jy,int jm,int jd){
        int jy2=jy-979, jDayNo=365*jy2+(jy2/33)*8+((jy2%33+3)/4);
        for(int i=1;i<jm;i++) jDayNo+=(i<=6?31:30); jDayNo+=jd-1;
        int gDayNo=jDayNo+79, gy=1600+400*(gDayNo/146097); gDayNo%=146097;
        boolean leap=true;
        if(gDayNo>=36525){gDayNo--; gy+=100*(gDayNo/36524); gDayNo%=36524; if(gDayNo>=365)gDayNo++; else leap=false;}
        gy+=4*(gDayNo/1461); gDayNo%=1461;
        if(gDayNo>=366){leap=false;gDayNo--;gy+=gDayNo/365;gDayNo%=365;}
        int[] md={31,28,31,30,31,30,31,31,30,31,30,31};
        int gm=1; while(gDayNo>=md[gm-1]+((gm==2&&leap)?1:0)){gDayNo-=md[gm-1]+((gm==2&&leap)?1:0);gm++;}
        return LocalDate.of(gy,gm,gDayNo+1);
    }
    public static String format(int y,int m,int d){return y+"/"+String.format("%02d",m)+"/"+String.format("%02d",d);}
}
